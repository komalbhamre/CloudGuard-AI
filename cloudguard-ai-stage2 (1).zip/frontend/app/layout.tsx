import "./globals.css";
import "@xyflow/react/dist/style.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "CloudGuard AI",
  description: "Cloud security posture and attack-path analysis dashboard",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
