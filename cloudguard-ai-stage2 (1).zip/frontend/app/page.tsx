"use client";

import { useMemo, useState } from "react";
import {
  AlertTriangle, ArrowRight, Bot, CheckCircle2, ChevronDown, Cloud,
  Database, FileWarning, GitBranch, Globe2, LockKeyhole, Network,
  RefreshCw, Search, Server, Shield, UploadCloud, XCircle, Zap,
} from "lucide-react";
import {
  Background, Controls, Edge, MarkerType, MiniMap, Node, ReactFlow,
  ReactFlowProvider, Position,
} from "@xyflow/react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

type Finding = {
  id: string; title: string; severity: string; resource: string;
  evidence: Record<string, unknown>; recommendation: string; attack_path: string[];
};
type Resource = { id: string; name: string; type: string; properties: Record<string, unknown> };
type Scan = {
  filename: string;
  summary: { resources: number; findings: number; rules_evaluated: number };
  risk: { score: number; counts: Record<string, number> };
  resources: Resource[];
  relationships: { source: string; target: string; type: string }[];
  attack_paths: { target: string; path: string[] }[];
  findings: Finding[];
  rule_catalog: { id: string; title: string; severity: string }[];
};

type Tab = "overview" | "topology" | "findings" | "rules";

const severityClass: Record<string, string> = {
  critical: "border-red-500/30 bg-red-500/10 text-red-300",
  high: "border-orange-500/30 bg-orange-500/10 text-orange-300",
  medium: "border-yellow-500/30 bg-yellow-500/10 text-yellow-300",
  low: "border-slate-600 bg-slate-800/50 text-slate-300",
};

const iconFor = (type: string) => {
  if (type === "internet") return Globe2;
  if (type === "vnet" || type === "subnet") return Network;
  if (type === "nsg") return Shield;
  if (type === "vm") return Server;
  if (type === "nic") return Cloud;
  if (type === "public_ip") return Globe2;
  if (type === "route_table") return GitBranch;
  return Database;
};

function Stat({ label, value, hint, danger }: { label: string; value: string | number; hint?: string; danger?: boolean }) {
  return <div className="panel p-5">
    <div className="flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-widest text-slate-500">{label}</p>{danger ? <AlertTriangle className="h-4 w-4 text-red-400" /> : null}</div>
    <p className={`mt-2 text-3xl font-bold ${danger ? "text-red-300" : "text-slate-100"}`}>{value}</p>
    {hint ? <p className="mt-1 text-xs text-slate-500">{hint}</p> : null}
  </div>;
}

function Severity({ value }: { value: string }) {
  return <span className={`rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${severityClass[value] || severityClass.low}`}>{value}</span>;
}

function Topology({ scan }: { scan: Scan }) {
  const { nodes, edges } = useMemo(() => {
    const groups: Record<string, Resource[]> = {};
    scan.resources.forEach(r => { (groups[r.type] ||= []).push(r); });
    const ordered = ["vnet", "subnet", "nsg", "route_table", "public_ip", "nic", "vm"];
    const nodes: Node[] = [{
      id: "internet", data: { label: <div className="flex items-center gap-2"><Globe2 className="h-4 w-4" /><span>Internet</span></div> },
      position: { x: 30, y: 260 }, sourcePosition: Position.Right, targetPosition: Position.Left,
      style: { background: "#1d1320", color: "#fca5a5", border: "1px solid #7f1d1d", width: 150, padding: 12 },
    }];
    let y = 40;
    ordered.forEach(type => {
      (groups[type] || []).forEach((r, i) => {
        const Icon = iconFor(type);
        nodes.push({
          id: r.id,
          data: { label: <div className="flex items-center gap-2"><Icon className="h-4 w-4 text-cyan-300" /><div><div className="font-semibold">{r.name}</div><div className="text-[10px] opacity-60">{type}</div></div></div> },
          position: { x: 230 + (i % 2) * 230, y: y + Math.floor(i / 2) * 90 },
          sourcePosition: Position.Right, targetPosition: Position.Left,
          style: { background: "#0c1625", color: "#e2e8f0", border: "1px solid #26364d", width: 190, padding: 10 },
        });
      });
      y += Math.max(90, (groups[type] || []).length * 45);
    });
    const edges: Edge[] = scan.relationships.map((r, i) => ({
      id: `e-${i}`, source: r.source, target: r.target, label: r.type,
      style: { stroke: "#475569", strokeWidth: 1.5 }, labelStyle: { fill: "#64748b", fontSize: 9 },
      markerEnd: { type: MarkerType.ArrowClosed, color: "#64748b" },
    })).filter(e => nodes.some(n => n.id === e.source) && nodes.some(n => n.id === e.target));
    scan.attack_paths.forEach((p, pi) => p.path.slice(0, -1).forEach((source, i) => {
      const target = p.path[i + 1];
      if (nodes.some(n => n.id === source) && nodes.some(n => n.id === target)) {
        edges.push({ id: `attack-${pi}-${i}`, source, target, animated: true, style: { stroke: "#ef4444", strokeWidth: 3 }, markerEnd: { type: MarkerType.ArrowClosed, color: "#ef4444" } });
      }
    }));
    return { nodes, edges };
  }, [scan]);

  return <div className="panel overflow-hidden">
    <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
      <div><h2 className="font-semibold">Live Cloud Topology</h2><p className="text-xs text-slate-500">Red animated edges show detected Internet-to-workload attack paths.</p></div>
      <div className="flex items-center gap-3 text-xs text-slate-500"><span className="flex items-center gap-1"><span className="h-2 w-5 rounded bg-red-500" /> attack path</span><span>{nodes.length - 1} resources</span></div>
    </div>
    <div className="h-[560px] bg-[#070d18]">
      <ReactFlowProvider><ReactFlow nodes={nodes} edges={edges} fitView minZoom={0.3} maxZoom={1.5} proOptions={{ hideAttribution: true }}>
        <Background gap={22} size={1} color="#172235" /><Controls /><MiniMap nodeColor="#1e3a5f" /></ReactFlow></ReactFlowProvider>
    </div>
  </div>;
}

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [scan, setScan] = useState<Scan | null>(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<Tab>("overview");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [ai, setAi] = useState<Record<string, string>>({});
  const [fix, setFix] = useState<Record<string, any>>({});
  const [openFinding, setOpenFinding] = useState<string | null>(null);

  async function analyze() {
    if (!file) return;
    setBusy(true);
    try {
      const f = new FormData(); f.append("file", file);
      const r = await fetch(`${API}/analyze`, { method: "POST", body: f });
      if (!r.ok) throw new Error(await r.text());
      setScan(await r.json()); setTab("overview");
    } catch (e) { alert(e instanceof Error ? e.message : "Analysis failed"); }
    finally { setBusy(false); }
  }

  async function explain(x: Finding) {
    const k = x.id + x.resource;
    const r = await fetch(`${API}/ai/explain`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ finding: x, context: { resources: scan?.resources, attack_paths: scan?.attack_paths } }) });
    const d = await r.json(); setAi(a => ({ ...a, [k]: d.answer || d.detail || "No AI response." }));
  }

  async function remediate(x: Finding) {
    const r = await fetch(`${API}/remediation/generate`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ finding: x }) });
    setFix(a => ({ ...a, [x.id + x.resource]: await r.json() }));
  }

  const findings = useMemo(() => (scan?.findings || []).filter(f => {
    const severityMatch = filter === "all" || f.severity === filter;
    const searchMatch = !search || `${f.id} ${f.title} ${f.resource}`.toLowerCase().includes(search.toLowerCase());
    return severityMatch && searchMatch;
  }), [scan, filter, search]);

  const score = scan?.risk.score || 0;
  const maxScore = Math.max(100, score);
  const scorePct = Math.min(100, Math.round((score / maxScore) * 100));

  return <main className="min-h-screen">
    <header className="border-b border-slate-800 bg-[#080d17]/90 backdrop-blur">
      <div className="mx-auto flex max-w-[1500px] items-center justify-between px-6 py-4">
        <div className="flex items-center gap-3"><div className="rounded-xl border border-cyan-500/30 bg-cyan-500/10 p-2"><Shield className="h-6 w-6 text-cyan-300" /></div><div><div className="text-lg font-bold tracking-tight">CloudGuard <span className="text-cyan-300">AI</span></div><div className="text-[10px] uppercase tracking-[.25em] text-slate-500">Cloud security command center</div></div></div>
        <div className="hidden items-center gap-3 text-xs text-slate-500 md:flex"><span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-400" /> Analyzer online</span><span>v0.2 Stage 2</span></div>
      </div>
    </header>

    <div className="mx-auto max-w-[1500px] px-6 py-7">
      <section className="panel mb-6 flex flex-col justify-between gap-5 p-6 lg:flex-row lg:items-center">
        <div><p className="text-xs font-bold uppercase tracking-[.25em] text-cyan-400">Azure configuration analysis</p><h1 className="mt-2 text-3xl font-bold md:text-4xl">See your cloud attack surface before attackers do.</h1><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-400">Upload a YAML or JSON cloud configuration. CloudGuard normalizes the topology, evaluates 15+ deterministic security checks, traces Internet exposure, and prepares AI explanations and remediation.</p></div>
        <div className="flex min-w-[320px] flex-col gap-3 rounded-xl border border-slate-800 bg-black/20 p-4">
          <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-dashed border-slate-700 bg-slate-950/60 p-3 hover:border-cyan-700"><UploadCloud className="h-5 w-5 text-cyan-300" /><div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{file?.name || "Choose configuration"}</div><div className="text-xs text-slate-500">.yaml, .yml or .json</div></div><input type="file" accept=".yaml,.yml,.json" className="hidden" onChange={e => setFile(e.target.files?.[0] || null)} /></label>
          <button disabled={!file || busy} onClick={analyze} className="flex items-center justify-center gap-2 rounded-lg bg-cyan-400 px-5 py-3 text-sm font-bold text-slate-950 disabled:cursor-not-allowed disabled:opacity-40">{busy ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}{busy ? "Analyzing topology..." : "Analyze Cloud"}</button>
        </div>
      </section>

      {!scan ? <EmptyState /> : <>
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <Stat label="Risk Index" value={score} hint="weighted finding score" danger={score >= 20} />
          <Stat label="Critical" value={scan.risk.counts.critical || 0} hint="requires attention" danger />
          <Stat label="High" value={scan.risk.counts.high || 0} hint="high impact findings" />
          <Stat label="Resources" value={scan.summary.resources} hint={`${scan.summary.rules_evaluated} rules evaluated`} />
          <Stat label="Attack Paths" value={scan.attack_paths.length} hint="Internet → workload" danger={scan.attack_paths.length > 0} />
        </section>

        <nav className="mt-6 flex gap-1 overflow-x-auto border-b border-slate-800">
          {([ ["overview", "Overview"], ["topology", "Network Topology"], ["findings", `Findings (${scan.summary.findings})`], ["rules", "Rule Library"] ] as [Tab,string][]).map(([id, label]) => <button key={id} onClick={() => setTab(id)} className={`border-b-2 px-4 py-3 text-sm font-semibold ${tab === id ? "border-cyan-400 text-cyan-300" : "border-transparent text-slate-500 hover:text-slate-300"}`}>{label}</button>)}
        </nav>

        {tab === "overview" && <Overview scan={scan} scorePct={scorePct} onTopology={() => setTab("topology")} onFindings={() => setTab("findings")} />}
        {tab === "topology" && <div className="mt-6"><Topology scan={scan} /></div>}
        {tab === "rules" && <RuleLibrary scan={scan} />}
        {tab === "findings" && <section className="mt-6"><FindingList findings={findings} filter={filter} setFilter={setFilter} search={search} setSearch={setSearch} openFinding={openFinding} setOpenFinding={setOpenFinding} ai={ai} fix={fix} explain={explain} remediate={remediate} /></section>}
      </>}
    </div>
  </main>;
}

function EmptyState() {
  return <div className="panel mt-6 flex min-h-[360px] items-center justify-center p-8 text-center"><div className="max-w-lg"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-cyan-500/20 bg-cyan-500/10"><Search className="h-8 w-8 text-cyan-300" /></div><h2 className="mt-5 text-2xl font-bold">No cloud scan yet</h2><p className="mt-2 text-sm leading-6 text-slate-500">Upload the sample vulnerable Azure configuration to see the dashboard, attack paths, 15+ security rules, AI explanation flow, and remediation generator.</p></div></div>;
}

function Overview({ scan, scorePct, onTopology, onFindings }: { scan: Scan; scorePct: number; onTopology: () => void; onFindings: () => void }) {
  const counts = scan.risk.counts;
  return <div className="mt-6 grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
    <div className="space-y-6">
      <Topology scan={scan} />
      <div className="grid gap-6 md:grid-cols-2">
        <div className="panel p-5"><div className="flex items-center justify-between"><h2 className="font-semibold">Risk distribution</h2><button onClick={onFindings} className="text-xs text-cyan-400">View findings <ArrowRight className="inline h-3 w-3" /></button></div><div className="mt-5 space-y-3">{["critical", "high", "medium", "low"].map(s => <div key={s} className="flex items-center gap-3"><span className="w-16 text-xs capitalize text-slate-500">{s}</span><div className="h-2 flex-1 rounded-full bg-slate-800"><div className="h-2 rounded-full bg-slate-500" style={{ width: `${Math.min(100, ((counts[s] || 0) / Math.max(1, scan.summary.findings)) * 100)}%` }} /></div><span className="w-6 text-right text-xs font-semibold">{counts[s] || 0}</span></div>)}</div></div>
        <div className="panel p-5"><h2 className="font-semibold">Scan summary</h2><div className="mt-4 space-y-3 text-sm">{[["Configuration", scan.filename], ["Resources", scan.summary.resources], ["Rules evaluated", scan.summary.rules_evaluated], ["Findings", scan.summary.findings], ["Attack paths", scan.attack_paths.length]].map(([a,b]) => <div key={String(a)} className="flex justify-between gap-3 border-b border-slate-800 pb-2"><span className="text-slate-500">{a}</span><span className="max-w-[60%] truncate font-semibold">{b}</span></div>)}</div></div>
      </div>
    </div>
    <aside className="space-y-6">
      <div className="panel p-6"><div className="flex items-center justify-between"><h2 className="font-semibold">Security posture</h2><LockKeyhole className="h-5 w-5 text-cyan-300" /></div><div className="mt-5 flex items-center gap-5"><div className="relative h-32 w-32"><svg viewBox="0 0 120 120" className="h-full w-full -rotate-90"><circle cx="60" cy="60" r="50" fill="none" stroke="#172235" strokeWidth="10"/><circle cx="60" cy="60" r="50" fill="none" stroke="currentColor" className={score >= 20 ? "text-red-400" : "text-cyan-400"} strokeWidth="10" strokeLinecap="round" strokeDasharray={`${scorePct * 3.14} 314`}/></svg><div className="absolute inset-0 flex items-center justify-center text-2xl font-bold">{score}</div></div><div><p className="text-sm text-slate-400">Weighted risk score</p><p className="mt-2 text-xs leading-5 text-slate-500">Critical findings carry more weight. This is a prioritization signal, not a compliance certification.</p></div></div></div>
      <div className="panel p-6"><div className="flex items-center gap-2"><GitBranch className="h-5 w-5 text-red-300" /><h2 className="font-semibold">Attack paths</h2></div>{scan.attack_paths.length ? <div className="mt-4 space-y-3">{scan.attack_paths.map((p, i) => <div key={i} className="rounded-xl border border-red-900/50 bg-red-950/20 p-4"><div className="text-xs font-bold uppercase tracking-wider text-red-300">Internet exposure</div><div className="mt-2 text-xs leading-5 text-slate-300">{p.path.join(" → ")}</div></div>)}</div> : <div className="mt-4 flex items-center gap-2 text-sm text-emerald-300"><CheckCircle2 className="h-4 w-4" /> No Internet-to-VM path detected.</div>}<button onClick={onTopology} className="mt-4 text-xs text-cyan-400">Open topology →</button></div>
    </aside>
  </div>;
}

function FindingList({ findings, filter, setFilter, search, setSearch, openFinding, setOpenFinding, ai, fix, explain, remediate }: any) {
  return <div className="panel p-5"><div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div><h2 className="text-xl font-bold">Security findings</h2><p className="mt-1 text-xs text-slate-500">Deterministic checks over the supplied configuration.</p></div><div className="flex flex-wrap gap-2"><div className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-950 px-3"><Search className="h-4 w-4 text-slate-500" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search findings..." className="w-44 bg-transparent py-2 text-xs outline-none" /></div>{["all", "critical", "high", "medium", "low"].map((x: string) => <button key={x} onClick={() => setFilter(x)} className={`rounded-lg border px-3 py-2 text-xs font-semibold capitalize ${filter === x ? "border-cyan-500/40 bg-cyan-500/10 text-cyan-300" : "border-slate-800 text-slate-500"}`}>{x}</button>)}</div></div><div className="mt-5 space-y-3">{findings.map((x: Finding) => <FindingCard key={x.id + x.resource} {...{x, openFinding, setOpenFinding, ai, fix, explain, remediate}} />)}{!findings.length && <p className="py-10 text-center text-sm text-slate-500">No findings match this filter.</p>}</div></div>;
}

function FindingCard({ x, openFinding, setOpenFinding, ai, fix, explain, remediate }: any) {
  const k = x.id + x.resource; const open = openFinding === k;
  return <article className="rounded-xl border border-slate-800 bg-slate-950/50"><button onClick={() => setOpenFinding(open ? null : k)} className="flex w-full items-center gap-4 p-4 text-left"><div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${x.severity === "critical" ? "bg-red-500/10" : "bg-slate-800"}`}>{x.severity === "critical" ? <XCircle className="h-5 w-5 text-red-400" /> : <FileWarning className="h-5 w-5 text-slate-400" />}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><Severity value={x.severity} /><span className="font-mono text-[10px] text-slate-600">{x.id}</span></div><h3 className="mt-1 truncate font-semibold">{x.title}</h3><p className="text-xs text-slate-500">{x.resource}</p></div><ChevronDown className={`h-4 w-4 text-slate-500 transition ${open ? "rotate-180" : ""}`} /></button>{open && <div className="border-t border-slate-800 p-5"><div className="grid gap-5 lg:grid-cols-2"><div><p className="text-xs font-bold uppercase tracking-wider text-slate-500">Evidence</p><pre className="mt-2 max-h-56 overflow-auto rounded-lg border border-slate-800 bg-black p-4 text-xs text-slate-300">{JSON.stringify(x.evidence, null, 2)}</pre></div><div><p className="text-xs font-bold uppercase tracking-wider text-slate-500">Recommended remediation</p><p className="mt-2 text-sm leading-6 text-slate-400">{x.recommendation}</p><p className="mt-5 text-xs font-bold uppercase tracking-wider text-slate-500">Attack path</p><p className="mt-2 text-xs text-red-300">{x.attack_path.length ? x.attack_path.join(" → ") : "No direct path established."}</p></div></div><div className="mt-5 flex flex-wrap gap-2"><button onClick={() => explain(x)} className="flex items-center gap-2 rounded-lg border border-cyan-700/50 bg-cyan-500/5 px-3 py-2 text-xs font-semibold text-cyan-300"><Bot className="h-4 w-4" /> Explain with Nebius AI</button><button onClick={() => remediate(x)} className="rounded-lg border border-emerald-700/50 bg-emerald-500/5 px-3 py-2 text-xs font-semibold text-emerald-300">Generate remediation</button></div>{ai[k] && <div className="mt-4 rounded-xl border border-cyan-900/50 bg-cyan-950/20 p-4"><div className="flex items-center gap-2 text-xs font-bold text-cyan-300"><Bot className="h-4 w-4" /> CloudGuard AI explanation</div><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-300">{ai[k]}</p></div>}{fix[k] && <div className="mt-4 grid gap-4 md:grid-cols-2"><Code title="Terraform" value={fix[k].terraform} /><Code title="Azure CLI" value={fix[k].azure_cli} /></div>}</div>}</article>;
}

function Code({ title, value }: { title: string; value?: string }) { return <div><p className="mb-2 text-xs font-semibold text-slate-400">{title}</p><pre className="max-h-64 overflow-auto rounded-lg border border-slate-800 bg-black p-4 text-xs text-emerald-300">{value || "No template generated."}</pre></div>; }

function RuleLibrary({ scan }: { scan: Scan }) {
  return <div className="mt-6 panel p-5"><div className="flex items-center justify-between"><div><h2 className="text-xl font-bold">CloudGuard rule library</h2><p className="mt-1 text-xs text-slate-500">The backend currently evaluates 15 deterministic checks; the core Stage 2 security set contains the 15 requested categories.</p></div><div className="rounded-lg border border-cyan-500/20 bg-cyan-500/5 px-3 py-2 text-xs text-cyan-300">{scan.rule_catalog.length} active rules</div></div><div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">{scan.rule_catalog.map(r => <div key={r.id} className="rounded-xl border border-slate-800 bg-slate-950/50 p-4"><div className="flex items-center justify-between"><span className="font-mono text-xs text-slate-600">{r.id}</span><Severity value={r.severity} /></div><p className="mt-3 text-sm font-semibold">{r.title}</p></div>)}</div></div>;
}
