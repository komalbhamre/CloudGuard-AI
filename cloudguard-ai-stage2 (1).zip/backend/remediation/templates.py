def terraform_for_finding(f):
    nsg=f.get("resource","web-nsg"); rid=f.get("id")
    if rid=="NSG-002": port="3389"; name="Restrict-RDP"
    elif rid=="NSG-003": port="22"; name="Restrict-SSH"
    else: return "# No deterministic Terraform template is available for this finding yet."
    return f'''# Review the source CIDR before applying.\nresource "azurerm_network_security_rule" "{name.lower().replace('-','_')}" {{\n  name                        = "{name}"\n  priority                    = 100\n  direction                   = "Inbound"\n  access                      = "Allow"\n  protocol                    = "Tcp"\n  source_port_range           = "*"\n  destination_port_range      = "{port}"\n  source_address_prefix       = "10.10.0.0/24"\n  destination_address_prefix  = "*"\n  resource_group_name         = var.resource_group_name\n  network_security_group_name = "{nsg}"\n}}'''

def azure_cli_for_finding(f):
    nsg=f.get("resource","web-nsg"); rid=f.get("id")
    rule="Allow-RDP" if rid=="NSG-002" else "Allow-SSH" if rid=="NSG-003" else None
    if not rule:return "# No deterministic Azure CLI template is available yet."
    return f'''az network nsg rule update \\\n  --resource-group <resource-group> \\\n  --nsg-name "{nsg}" \\\n  --name "{rule}" \\\n  --source-address-prefixes "10.10.0.0/24"'''
