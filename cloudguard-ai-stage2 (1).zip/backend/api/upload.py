from fastapi import APIRouter, UploadFile, File, HTTPException
from parser.config_parser import parse_config, ConfigParseError
from normalizer.cloud_model import normalize
from analyzer.rules import analyze_rules, rule_catalog
from analyzer.attack_path import find_paths
from analyzer.risk import calculate_risk

router = APIRouter()


@router.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    try:
        config = parse_config(file.filename or "config.yaml", await file.read())
    except ConfigParseError as e:
        raise HTTPException(400, str(e))

    model = normalize(config)
    findings = analyze_rules(config)
    paths = find_paths(model)
    path_values = [p["path"] for p in paths]

    # A finding gets a matching path only when the vulnerable resource participates
    # in a detected Internet-to-VM route. Otherwise the UI correctly shows that
    # no direct attack path was established from the supplied topology.
    for f in findings:
        for p in paths:
            if f["resource"] in p["path"]:
                f["attack_path"] = p["path"]
                break
        if not f["attack_path"] and f["id"] in {"NSG-002", "NSG-003", "NSG-004", "NSG-005", "PUB-001", "PUB-002"} and path_values:
            f["attack_path"] = path_values[0]

    resources = [
        {"id": r.id, "name": r.name, "type": r.resource_type, "properties": r.properties}
        for r in model.resources
    ]
    return {
        "filename": file.filename,
        "summary": {"resources": len(resources), "findings": len(findings), "rules_evaluated": len(rule_catalog())},
        "risk": calculate_risk(findings),
        "resources": resources,
        "relationships": model.relationships,
        "attack_paths": paths,
        "findings": findings,
        "rule_catalog": rule_catalog(),
        "config": config,
    }


@router.get("/rules")
def rules():
    return {"rules": rule_catalog()}
