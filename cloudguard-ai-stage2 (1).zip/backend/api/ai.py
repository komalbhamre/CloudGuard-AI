from fastapi import APIRouter,HTTPException
from pydantic import BaseModel
from ai.nebius_client import explain_finding
router=APIRouter(prefix="/ai")
class ExplainRequest(BaseModel):
    finding:dict
    context:dict={}
@router.post("/explain")
def explain(req:ExplainRequest):
    try:return {"answer":explain_finding(req.finding,req.context)}
    except Exception as e: raise HTTPException(500,f"AI request failed: {e}")
