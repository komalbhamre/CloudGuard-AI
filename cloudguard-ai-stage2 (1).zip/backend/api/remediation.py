from fastapi import APIRouter
from pydantic import BaseModel
from remediation.templates import terraform_for_finding,azure_cli_for_finding
router=APIRouter(prefix="/remediation")
class Request(BaseModel): finding:dict
@router.post("/generate")
def generate(req:Request): return {"terraform":terraform_for_finding(req.finding),"azure_cli":azure_cli_for_finding(req.finding),"warning":"Review the generated change before applying it."}
