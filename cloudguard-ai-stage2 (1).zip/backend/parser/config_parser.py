import json
from pathlib import Path
import yaml

class ConfigParseError(ValueError): pass

def parse_config(filename: str, content: bytes) -> dict:
    suffix = Path(filename).suffix.lower()
    try:
        text = content.decode("utf-8")
        if suffix == ".json": data = json.loads(text)
        elif suffix in {".yaml", ".yml"}: data = yaml.safe_load(text)
        else: raise ConfigParseError("Only JSON and YAML are supported in the MVP.")
    except (UnicodeDecodeError, json.JSONDecodeError, yaml.YAMLError) as exc:
        raise ConfigParseError(f"Invalid configuration: {exc}") from exc
    if not isinstance(data, dict): raise ConfigParseError("Root configuration must be an object/map.")
    return data
