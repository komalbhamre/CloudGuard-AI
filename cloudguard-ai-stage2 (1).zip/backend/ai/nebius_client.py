import os
from dotenv import load_dotenv
from openai import OpenAI
load_dotenv()

def explain_finding(finding,context):
    key=os.getenv("NEBIUS_API_KEY"); model=os.getenv("NEBIUS_MODEL")
    if not key or not model:
        return "Nebius is not configured. Set NEBIUS_API_KEY and NEBIUS_MODEL in backend/.env."
    client=OpenAI(api_key=key,base_url=os.getenv("NEBIUS_BASE_URL","https://api.tokenfactory.nebius.com/v1/"))
    system="""You are CloudGuard AI. Explain only evidence supplied by the application. Never invent resources, ports, rules, vulnerabilities or actions. Never claim remediation was applied. Explain what happened, why it matters, evidence, attack path if available, recommended remediation, and a simple manager-friendly summary."""
    response=client.chat.completions.create(model=model,temperature=0.2,messages=[{"role":"system","content":system},{"role":"user","content":str({"finding":finding,"context":context})}])
    return response.choices[0].message.content
