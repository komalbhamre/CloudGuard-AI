from dataclasses import dataclass, field
from typing import Any

@dataclass
class CloudResource:
    id: str
    name: str
    resource_type: str
    properties: dict[str, Any] = field(default_factory=dict)

@dataclass
class CloudModel:
    resources: list[CloudResource]
    relationships: list[dict[str, str]]
    def by_type(self, t):
        return [r for r in self.resources if r.resource_type == t]


def normalize(config: dict) -> CloudModel:
    resources: list[CloudResource] = []
    rel: list[dict[str, str]] = []

    def add_many(key: str, resource_type: str):
        for x in config.get(key, []) or []:
            if x.get("name"):
                resources.append(CloudResource(f"{resource_type}:{x['name']}", x["name"], resource_type, x))

    if config.get("vnet", {}).get("name"):
        x = config["vnet"]
        resources.append(CloudResource(f"vnet:{x['name']}", x["name"], "vnet", x))

    for key, resource_type in [
        ("vnets", "vnet"), ("subnets", "subnet"), ("nsgs", "nsg"),
        ("nics", "nic"), ("public_ips", "public_ip"), ("vms", "vm"),
        ("route_tables", "route_table"),
    ]:
        add_many(key, resource_type)

    for x in config.get("subnets", []) or []:
        if x.get("nsg"):
            rel.append({"source": f"nsg:{x['nsg']}", "target": f"subnet:{x['name']}", "type": "protects"})
        if x.get("vnet"):
            rel.append({"source": f"vnet:{x['vnet']}", "target": f"subnet:{x['name']}", "type": "contains"})
        if x.get("route_table"):
            rel.append({"source": f"route_table:{x['route_table']}", "target": f"subnet:{x['name']}", "type": "routes"})

    for x in config.get("nics", []) or []:
        if x.get("subnet"):
            rel.append({"source": f"subnet:{x['subnet']}", "target": f"nic:{x['name']}", "type": "contains"})
        if x.get("nsg"):
            rel.append({"source": f"nsg:{x['nsg']}", "target": f"nic:{x['name']}", "type": "protects"})
        if x.get("public_ip"):
            rel.append({"source": f"public_ip:{x['public_ip']}", "target": f"nic:{x['name']}", "type": "attached_to"})

    for x in config.get("vms", []) or []:
        if x.get("nic"):
            rel.append({"source": f"nic:{x['nic']}", "target": f"vm:{x['name']}", "type": "attached_to"})

    return CloudModel(resources, rel)
