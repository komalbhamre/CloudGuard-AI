from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.upload import router as upload_router
from api.ai import router as ai_router
from api.remediation import router as remediation_router

app = FastAPI(title="CloudGuard AI", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(upload_router)
app.include_router(ai_router)
app.include_router(remediation_router)


@app.get("/")
def root():
    return {"name": "CloudGuard AI", "version": "0.2.0", "status": "running"}


@app.get("/health")
def health():
    return {"status": "healthy"}
