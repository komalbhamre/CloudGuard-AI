WEIGHTS={"critical":10,"high":6,"medium":3,"low":1}
def calculate_risk(findings):
    counts={k:0 for k in WEIGHTS}
    for f in findings: counts[f["severity"].lower()]=counts.get(f["severity"].lower(),0)+1
    return {"score":sum(WEIGHTS[k]*v for k,v in counts.items()),"counts":counts}
