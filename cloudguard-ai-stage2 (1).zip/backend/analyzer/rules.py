from collections import Counter
from typing import Any


def finding(i: str, title: str, severity: str, resource: str, evidence: Any, recommendation: str):
    return {
        "id": i,
        "title": title,
        "severity": severity,
        "resource": resource,
        "evidence": evidence,
        "recommendation": recommendation,
        "attack_path": [],
    }


def _allow(rule: dict) -> bool:
    return str(rule.get("access", "")).lower() == "allow"


def _source(rule: dict) -> str:
    return str(rule.get("source", "")).strip()


def _port(rule: dict) -> str:
    return str(rule.get("destination_port", "")).strip()


def _protocol(rule: dict) -> str:
    return str(rule.get("protocol", "")).lower().strip()


def _internet(source: str) -> bool:
    return source in {"0.0.0.0/0", "*", "internet", "any"}


def _ports(value: str) -> set[str]:
    return {p.strip() for p in value.split(",") if p.strip()}


def check_missing_nsg(c):
    out = []
    for s in c.get("subnets", []) or []:
        if not s.get("nsg"):
            out.append(finding(
                "NSG-001", "Subnet has no NSG association", "medium", s["name"], s,
                "Associate an NSG that allows only the traffic required by this subnet."
            ))
    return out


def check_rdp(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _protocol(r) == "tcp" and _port(r) == "3389" and _internet(_source(r)):
                out.append(finding(
                    "NSG-002", "Internet exposed RDP", "critical", n["name"], r,
                    "Restrict RDP to a trusted management network, VPN, or bastion host."
                ))
    return out


def check_ssh(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _protocol(r) == "tcp" and _port(r) == "22" and _internet(_source(r)):
                out.append(finding(
                    "NSG-003", "Internet exposed SSH", "high", n["name"], r,
                    "Restrict SSH to a trusted management network, VPN, or bastion host."
                ))
    return out


def check_any_any(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _internet(_source(r)) and _port(r).lower() in {"*", "any"} and _protocol(r) in {"*", "any"}:
                out.append(finding(
                    "NSG-004", "Unrestricted Any/Any inbound rule", "critical", n["name"], r,
                    "Remove the unrestricted rule and allow only required protocols, ports, and sources."
                ))
    return out


def check_wide(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and "-" in _port(r):
                out.append(finding(
                    "NSG-005", "Wide inbound port range", "high", n["name"], r,
                    "Replace broad port ranges with the smallest set of required ports."
                ))
    return out


def check_public_http(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _protocol(r) == "tcp" and _port(r) == "80" and _internet(_source(r)):
                out.append(finding(
                    "NSG-006", "Internet exposed HTTP", "medium", n["name"], r,
                    "Use HTTPS for application traffic. If HTTP is required for redirect, keep the exposure intentional and narrow."
                ))
    return out


def check_public_https(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _protocol(r) == "tcp" and _port(r) == "443" and _internet(_source(r)):
                out.append(finding(
                    "NSG-007", "Internet exposed HTTPS", "low", n["name"], r,
                    "Confirm the workload is intended to be public and place it behind appropriate application-layer protection where applicable."
                ))
    return out


def check_database_ports(c):
    database_ports = {"1433": "SQL Server", "3306": "MySQL", "5432": "PostgreSQL", "6379": "Redis", "27017": "MongoDB"}
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _internet(_source(r)) and _port(r) in database_ports:
                service = database_ports[_port(r)]
                out.append(finding(
                    "NSG-008", f"Internet exposed {service} port", "critical", n["name"], r,
                    f"Do not expose {service} directly to the Internet. Restrict the port to application or management subnets."
                ))
    return out


def check_management_ports(c):
    management = {"22": "SSH", "3389": "RDP", "5985": "WinRM HTTP", "5986": "WinRM HTTPS"}
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _internet(_source(r)) and _port(r) in management:
                out.append(finding(
                    "NSG-009", f"Broad Internet access to {management[_port(r)]}", "high", n["name"], r,
                    "Limit management access to approved administration networks or a secure bastion path."
                ))
    return out


def check_icmp(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _internet(_source(r)) and _protocol(r) == "icmp":
                out.append(finding(
                    "NSG-010", "Internet ICMP allowed", "medium", n["name"], r,
                    "Disable Internet ICMP unless it is explicitly required for monitoring or diagnostics."
                ))
    return out


def check_udp(c):
    out = []
    for n in c.get("nsgs", []) or []:
        for r in n.get("rules", []) or []:
            if _allow(r) and _internet(_source(r)) and _protocol(r) == "udp" and _port(r).lower() in {"*", "any"}:
                out.append(finding(
                    "NSG-011", "Unrestricted Internet UDP", "high", n["name"], r,
                    "Allow only the specific UDP ports and trusted sources required by the workload."
                ))
    return out


def check_duplicate_rules(c):
    out = []
    for n in c.get("nsgs", []) or []:
        seen: Counter = Counter()
        for r in n.get("rules", []) or []:
            key = (
                str(r.get("source", "")), str(r.get("destination", "*")),
                str(r.get("destination_port", "")), str(r.get("protocol", "")),
                str(r.get("access", "")),
            )
            seen[key] += 1
        for key, count in seen.items():
            if count > 1:
                out.append(finding(
                    "NSG-012", "Duplicate NSG rule", "low", n["name"], {"rule": key, "duplicates": count},
                    "Remove duplicate rules to reduce configuration noise and simplify security review."
                ))
    return out


def check_public_ip(c):
    public = {x.get("name") for x in c.get("public_ips", []) or []}
    out = []
    for n in c.get("nics", []) or []:
        if n.get("public_ip") in public:
            out.append(finding(
                "PUB-001", "Public IP attached to workload NIC", "high", n["name"],
                {"public_ip": n.get("public_ip")},
                "Remove the public IP when direct Internet exposure is not required."
            ))
    return out


def check_internet_default_route(c):
    out = []
    for rt in c.get("route_tables", []) or []:
        for route in rt.get("routes", []) or []:
            prefix = str(route.get("address_prefix", route.get("destination", ""))).strip()
            hop = str(route.get("next_hop", route.get("next_hop_type", ""))).lower().strip()
            if prefix == "0.0.0.0/0" and hop in {"internet", "internetgateway", "internet_gateway"}:
                out.append(finding(
                    "NET-001", "Subnet route sends default traffic to Internet", "medium", rt["name"], route,
                    "Confirm the default Internet route is required. For private workloads, use controlled egress such as Azure Firewall or NAT."
                ))
    return out


def check_public_ip_without_nsg(c):
    nsg_by_name = {x.get("name"): x for x in c.get("nsgs", []) or []}
    subnet_by_name = {x.get("name"): x for x in c.get("subnets", []) or []}
    public = {x.get("name") for x in c.get("public_ips", []) or []}
    out = []
    for nic in c.get("nics", []) or []:
        if nic.get("public_ip") not in public:
            continue
        subnet = subnet_by_name.get(nic.get("subnet"), {})
        if not subnet.get("nsg") and not nic.get("nsg"):
            out.append(finding(
                "PUB-002", "Publicly addressed NIC has no NSG", "critical", nic["name"],
                {"public_ip": nic.get("public_ip"), "subnet": nic.get("subnet")},
                "Attach an NSG to the subnet or NIC and explicitly allow only required inbound traffic."
            ))
    return out



RULES = [
    check_missing_nsg,
    check_rdp,
    check_ssh,
    check_any_any,
    check_wide,
    check_public_http,
    check_public_https,
    check_database_ports,
    check_management_ports,
    check_icmp,
    check_udp,
    check_duplicate_rules,
    check_public_ip,
    check_internet_default_route,
    check_public_ip_without_nsg,
]


def analyze_rules(c):
    out = []
    for rule in RULES:
        out.extend(rule(c))
    return out


def rule_catalog():
    return [
        {"id": "NSG-001", "title": "Subnet has no NSG association", "severity": "medium"},
        {"id": "NSG-002", "title": "Internet exposed RDP", "severity": "critical"},
        {"id": "NSG-003", "title": "Internet exposed SSH", "severity": "high"},
        {"id": "NSG-004", "title": "Unrestricted Any/Any inbound rule", "severity": "critical"},
        {"id": "NSG-005", "title": "Wide inbound port range", "severity": "high"},
        {"id": "NSG-006", "title": "Internet exposed HTTP", "severity": "medium"},
        {"id": "NSG-007", "title": "Internet exposed HTTPS", "severity": "low"},
        {"id": "NSG-008", "title": "Internet exposed database port", "severity": "critical"},
        {"id": "NSG-009", "title": "Broad Internet management access", "severity": "high"},
        {"id": "NSG-010", "title": "Internet ICMP allowed", "severity": "medium"},
        {"id": "NSG-011", "title": "Unrestricted Internet UDP", "severity": "high"},
        {"id": "NSG-012", "title": "Duplicate NSG rule", "severity": "low"},
        {"id": "PUB-001", "title": "Public IP attached to workload NIC", "severity": "high"},
        {"id": "NET-001", "title": "Internet default route", "severity": "medium"},
        {"id": "PUB-002", "title": "Publicly addressed NIC has no NSG", "severity": "critical"},
    ]
