import networkx as nx

def build_graph(model):
    g=nx.DiGraph(); g.add_node("internet",name="Internet",resource_type="internet")
    for r in model.resources: g.add_node(r.id,name=r.name,resource_type=r.resource_type)
    for rel in model.relationships: g.add_edge(rel["source"],rel["target"],relationship=rel["type"])
    for p in model.by_type("public_ip"): g.add_edge("internet",p.id,relationship="internet_access")
    return g

def find_paths(model):
    g=build_graph(model); out=[]
    for vm in model.by_type("vm"):
        try: out.append({"target":vm.name,"path":nx.shortest_path(g,"internet",vm.id)})
        except nx.NetworkXNoPath: pass
    return out
