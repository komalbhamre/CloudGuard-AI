# CloudGuard AI — Stage 2

CloudGuard is a hackathon-ready cloud security analysis MVP. Stage 2 adds:

- Full security command-center dashboard
- React Flow network topology
- Red animated attack-path visualization
- 15 deterministic security checks
- Finding search and severity filters
- Rule library view
- AI explanation and remediation actions from the Stage 1 backend
- Demo configuration at `examples/stage2-demo.yaml`

## Architecture

```text
YAML / JSON
    ↓
FastAPI upload API
    ↓
Parser → Normalizer → Rule Engine (17 checks)
                 ↘ Attack-path graph (NetworkX)
    ↓
JSON scan result
    ↓
Next.js + React Flow dashboard
    ↓
Nebius AI explanation / remediation templates
```

## 1. Backend

From the project root:

```powershell
cd backend
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn main:app --reload --port 8000
```

API:

- `GET /health`
- `GET /rules`
- `POST /analyze`
- `POST /ai/explain`
- `POST /remediation/generate`

## 2. Frontend

Open a second terminal:

```powershell
cd frontend
npm install
copy .env.local.example .env.local
npm run dev
```

Open `http://localhost:3000`.

## 3. Demo

Upload:

```text
examples/stage2-demo.yaml
```

It intentionally contains public RDP, HTTP, a wide port range, unrestricted UDP, a public IP, database exposure, duplicate rules, a missing NSG, and a default Internet route so the dashboard has meaningful findings.

## 4. Stage 2 rule set

1. NSG-001 — subnet without NSG
2. NSG-002 — Internet RDP
3. NSG-003 — Internet SSH
4. NSG-004 — Internet Any/Any
5. NSG-005 — wide port range
6. NSG-006 — Internet HTTP
7. NSG-007 — Internet HTTPS
8. NSG-008 — Internet database port
9. NSG-009 — broad management ports
10. NSG-010 — Internet ICMP
11. NSG-011 — unrestricted Internet UDP
12. NSG-012 — duplicate rule
13. PUB-001 — public IP on workload NIC
14. NET-001 — default Internet route
15. PUB-002 — public NIC without NSG

The 15 checks are the active Stage 2 rule set.

## Important scope note

This Stage 2 parser still uses CloudGuard's normalized YAML/JSON schema. It does **not** yet parse native Azure ARM/Bicep/Terraform files. That should be the next implementation stage.
